/*
 Name:		ESP32 APRS Internet Gateway
 Created:	1-Nov-2021 14:27:23
 Author:	HS5TQA/Atten
 APRS AIO added by:	TA1AYH/Mehmet
 Support IS: host:aprs.dprns.com port:14580
 Support IS monitor: http://aprs.dprns.com:14501
 Support in LINE Group APRS Only
*/

#include "main.h"
#include <KISS.h>
#include "webservice.h"
#include "ESP32Ping.h"
#include <WiFi.h>
#include <WiFiClient.h>
#include "cppQueue.h"
#include "BluetoothSerial.h"
#include "digirepeater.h"
#include "igate.h"
// #include "wireguard.h"
#include "TinyGPS++.h"
#include <parse_aprs.h>
#include <Fonts/FreeSansBold9pt7b.h>
#include "wireguard_vpn.h"
#include <WiFiClientSecure.h>
#include "AFSK.h"
#include <PPPoS.h>

#define EEPROM_SIZE 1024
#ifdef SDCARD
#include <SPI.h> //SPI.h must be included as DMD is written by SPI (the IDE complains otherwise)
#include "FS.h"
#include "SPIFFS.h"
#define SDCARD_CS 13
#define SDCARD_CLK 14
#define SDCARD_MOSI 15
#define SDCARD_MISO 2
#endif

#ifdef OLED
#include <Wire.h>
#include "Adafruit_SSD1306.h"
#include <Adafruit_GFX.h>
// #include <Adafruit_I2CDevice.h>

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
// The pins for I2C are defined by the Wire-library.
// On an arduino UNO:       A4(SDA), A5(SCL)
// On an arduino MEGA 2560: 20(SDA), 21(SCL)
// On an arduino LEONARDO:   2(SDA),  3(SCL), ...
#define OLED_RESET 4        // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3D ///< See datasheet for Address; 0x3D for 128x64, 0x3C for 128x32
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// For a connection via I2C using the Arduino Wire include:
// #include <Wire.h>		 // Only needed for Arduino 1.6.5 and earlier
// #include "SSD1306Wire.h" // legacy: #include "SSD1306.h"
// OR #include "SH1106Wire.h"   // legacy: #include "SH1106.h"

// Initialize the OLED display using Arduino Wire:
// SSD1306Wire display(0x3c, SDA, SCL, GEOMETRY_128_64); // ADDRESS, SDA, SCL  -  SDA and SCL usually populate automatically based on your board's pins_arduino.h e.g. https://github.com/esp8266/Arduino/blob/master/variants/nodemcu/pins_arduino.h
// SSD1306Wire display(0x3c, D3, D5);  // ADDRESS, SDA, SCL  -  If not, they can be specified manually.
// SSD1306Wire display(0x3c, SDA, SCL, GEOMETRY_128_32);  // ADDRESS, SDA, SCL, OLEDDISPLAY_GEOMETRY  -  Extra param required for 128x32 displays.
// SH1106Wire display(0x3c, SDA, SCL);     // ADDRESS, SDA, SCL

#endif

struct pbuf_t aprs;
ParseAPRS aprsParse;
double lat;
double lon;
int Alt;
int Trk;
int OldTrk;
int Spd;
int SpdKm;

TinyGPSPlus gps;
TinyGPSCustom pdop(gps, "GPGSA", 15); // $GPGSA sentence, 15th element
TinyGPSCustom hdop(gps, "GPGSA", 16); // $GPGSA sentence, 16th element
TinyGPSCustom vdop(gps, "GPGSA", 17); // $GPGSA sentence, 17th element

#ifdef SA818
/*
#define VBAT_PIN 35
#define WIRE 4
#define POWER_PIN 12
#define PULLDOWN_PIN 27
*/
#define SQL_PIN 33
HardwareSerial SerialRF(2);
#endif

// #define MODEM_PWRKEY 5
// #define MODEM_TX 17
// #define MODEM_RX 16

#define LED_TX 4
#define LED_RX 2

#define PPP_APN "internet"
#define PPP_USER ""
#define PPP_PASS ""

const char *str_status[] = {
    "IDLE_STATUS",
    "NO_SSID_AVAIL",
    "SCAN_COMPLETED",
    "CONNECTED",
    "CONNECT_FAILED",
    "CONNECTION_LOST",
    "DISCONNECTED"};

// PPPoS ppp;

time_t systemUptime = 0;
time_t wifiUptime = 0;

boolean KISS = false;
bool aprsUpdate = false;

boolean gotPacket = false;
AX25Msg incomingPacket;

bool lastPkg = false;
bool afskSync = false;
String lastPkgRaw = "";
float dBV = 0;
int mVrms = 0;

cppQueue PacketBuffer(sizeof(AX25Msg), 5, IMPLEMENTATION); // Instantiate queue
cppQueue dispBuffer(300, 5, IMPLEMENTATION);

statusType status;
RTC_DATA_ATTR igateTLMType igateTLM;
RTC_DATA_ATTR txQueueType txQueue[PKGTXSIZE];

extern RTC_DATA_ATTR uint8_t digiCount;

Configuration config;

pkgListType pkgList[PKGLISTSIZE];

TelemetryType Telemetry[TLMLISTSIZE];

TaskHandle_t taskNetworkHandle;
TaskHandle_t taskAPRSHandle;

// HardwareSerial SerialTNC(2);
HardwareSerial SerialGPS(2);

// BluetoothSerial SerialBT;

// Set your Static IP address for wifi AP
IPAddress local_IP(192, 168, 4, 1);
IPAddress gateway(192, 168, 4, 254);
IPAddress subnet(255, 255, 255, 0);
IPAddress vpn_IP(192, 168, 44, 195);
int pkgTNC_count = 0;
uint8_t gwRaw[PKGLISTSIZE][66];
uint8_t gwRawSize[PKGLISTSIZE];
int gwRaw_count = 0, gwRaw_idx_rd = 0, gwRaw_idx_rw = 0;
long TrackTimer = 594;
long sendTimer = 0;
long sendTimeX = 0;
double old_lat;
double old_lon;
bool ready = false;
int digiDelay;
double distxy;
WiFiClient aprsClient;
long SerDelay = 0;
int Gps_Sec = 0;
double Old_GpsSec = 0;
bool GpsOnline = false;
long TrackDelay = 6000;
bool SA818_Active = false;
bool dispPush = 0;
unsigned long disp_delay = 0;
long oledSleepTimeout = 0;
bool showDisp = false;
bool moving = false;
bool StopSend = false;
bool AprsConnected = false;
bool GpsOkay()
{
  if (GpsOnline)
    return true;
  else
    return false;
}

String getValue(String data, char separator, int index)
{
  int found = 0;
  int strIndex[] = {0, -1};
  int maxIndex = data.length();

  for (int i = 0; i <= maxIndex && found <= index; i++)
  {
    if (data.charAt(i) == separator || i == maxIndex)
    {
      found++;
      strIndex[0] = strIndex[1] + 1;
      strIndex[1] = (i == maxIndex) ? i + 1 : i;
    }
  }
  return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
} // END

boolean isValidNumber(String str)
{
  for (byte i = 0; i < str.length(); i++)
  {
    if (isDigit(str.charAt(i)))
      return true;
  }
  return false;
}

uint8_t checkSum(uint8_t *ptr, size_t count)
{
  uint8_t lrc, tmp;
  uint16_t i;
  lrc = 0;
  for (i = 0; i < count; i++)
  {
    tmp = *ptr++;
    lrc = lrc ^ tmp;
  }
  return lrc;
}

void saveEEPROM()
{
  uint8_t chkSum = 0;
  byte *ptr;
  ptr = (byte *)&config;
  EEPROM.writeBytes(1, ptr, sizeof(Configuration));
  chkSum = checkSum(ptr, sizeof(Configuration));
  EEPROM.write(0, chkSum);
  EEPROM.commit();
#ifdef DEBUG
  Serial.print("Save EEPROM ChkSUM=");
  Serial.println(chkSum, HEX);
#endif
}

void defaultConfig()
{
  Serial.println("Default configure mode!");
  sprintf(config.aprs_mycall, "MYCALL");      // select your's
  sprintf(config.aprs_passcode, "00000");     // select your's
  sprintf(config.wifi_ssid, "APRSTH");        // select your's
  sprintf(config.wifi_pass, "aprsthnetwork"); // select your's
  sprintf(config.wifi_ap_ssid, "AIO_AP");
  sprintf(config.wifi_ap_pass, "aprsthnetwork");
  sprintf(config.aprs_comment, "APRS AIO Internet Gateway"); // select your's
  sprintf(config.tnc_comment, "APRS AIO TNC");               // select your's
  config.aprs_beacon = 600;
  config.aprs_ssid = 5;
  config.user_lat = 36.9030; // select your's  Lat.
  config.user_lon = 30.6880; // select your's  Lon.
  config.aprs_table = '/';   // select your's
  config.aprs_symbol = '(';  // select your's
  config.aprsTracker = true;
  config.inet2rf = true;
  config.tnc_digi = true;
  config.user_alt = 67;
  config.tnc = true;
  config.rf2inet = true;
  config.aprs = true;
  config.FeedBack = false;
  config.wifi_mode = WIFI_AP_STA_FIX; // WIFI_STA_FIX; // WIFI_AP_STA_FIX
  config.tnc_telemetry = false;
  sprintf(config.aprs_filter, "m/250"); // select your's "g/HS*/E2*"
  config.oled_enable = true;
  config.filterMessage = true;
  config.filterStatus = true;
  config.filterTelemetry = false;
  config.filterWeather = false;
  config.filterTracker = true;
  config.filterMove = true;
  config.filterPosition = true;
  config.dispINET = true;
  config.dispTNC = true;
  config.DisplayFilter = true;
  config.wifi_client = true;
  config.synctime = true;
  config.AddCounter = false;
  config.wifi_ch = 1;
  config.vpn = false;
  config.modem = false;
  config.digi_delay = 2000;
  config.tx_timeslot = 5000;
  config.dispDelay = 5; // Sec
  config.oled_timeout = 600;
  config.timeZone = 3; // select your time zone
  sprintf(config.aprs_path, "WIDE1-1");
  sprintf(config.aprs_dest, "APESPG");
  // sprintf(config.aprs_msgdest, "");
  sprintf(config.aprs_host, "rotate.aprs2.net"); // "aprs.dprns.com"
  sprintf(config.mqtt_host, "rotate.aprs2.net");
  config.aprs_port = 14580;
  sprintf(config.aprs_moniCall, "%s-%d", config.aprs_mycall, config.aprs_ssid);
  config.mqtt_port = 1883;
  config.tnc_btext[0] = 0;
  config.tnc_beacon = 0;
  config.wifi_power = 44;
  config.input_hpf = true;
  input_HPF = config.input_hpf;
  config.wg_port = 51820;
  sprintf(config.wg_peer_address, "203.150.19.23");
  sprintf(config.wg_local_address, "44.63.31.223");
  sprintf(config.wg_netmask_address, "255.255.255.255");
  sprintf(config.wg_gw_address, "44.63.31.193");
  sprintf(config.wg_public_key, " ");
  sprintf(config.wg_private_key, " ");
#ifdef SA818
  config.freq_rx = 144.8000;
  config.freq_tx = 144.8000;
  config.offset_rx = 0;
  config.offset_tx = 0;
  config.tone_rx = 0;
  config.tone_tx = 0;
  config.band = 1;
  config.sql_level = 0;
  config.rf_power = LOW;
  config.volume = 4;
#endif
  saveEEPROM();
}

unsigned long NTP_Timeout;
unsigned long pingTimeout;

int tlmList_Find(char *call)
{
  int i;
  for (i = 0; i < TLMLISTSIZE; i++)
  {
    if (strstr(Telemetry[i].callsign, call) != NULL)
      return i;
  }
  return -1;
}

int tlmListOld()
{
  int i, ret = 0;
  time_t minimum = Telemetry[0].time;
  for (i = 1; i < TLMLISTSIZE; i++)
  {
    if (Telemetry[i].time < minimum)
    {
      minimum = Telemetry[i].time;
      ret = i;
    }
    if (Telemetry[i].time > now())
      Telemetry[i].time = 0;
  }
  return ret;
}

char pkgList_Find(char *call)
{
  char i;
  for (i = 0; i < PKGLISTSIZE; i++)
  {
    if (strstr(pkgList[(int)i].calsign, call) != NULL)
      return i;
  }
  return -1;
}

char pkgListOld()
{
  char i, ret = 0;
  time_t minimum = pkgList[0].time;
  for (i = 1; i < PKGLISTSIZE; i++)
  {
    if (pkgList[(int)i].time < minimum)
    {
      minimum = pkgList[(int)i].time;
      ret = i;
    }
  }
  return ret;
}

void sort(pkgListType a[], int size)
{
  pkgListType t;
  char *ptr1;
  char *ptr2;
  char *ptr3;
  ptr1 = (char *)&t;
  for (int i = 0; i < (size - 1); i++)
  {
    for (int o = 0; o < (size - (i + 1)); o++)
    {
      if (a[o].time < a[o + 1].time)
      {
        ptr2 = (char *)&a[o];
        ptr3 = (char *)&a[o + 1];
        memcpy(ptr1, ptr2, sizeof(pkgListType));
        memcpy(ptr2, ptr3, sizeof(pkgListType));
        memcpy(ptr3, ptr1, sizeof(pkgListType));
      }
    }
  }
}

void sortPkgDesc(pkgListType a[], int size)
{
  pkgListType t;
  char *ptr1;
  char *ptr2;
  char *ptr3;
  ptr1 = (char *)&t;
  for (int i = 0; i < (size - 1); i++)
  {
    for (int o = 0; o < (size - (i + 1)); o++)
    {
      if (a[o].pkg < a[o + 1].pkg)
      {
        ptr2 = (char *)&a[o];
        ptr3 = (char *)&a[o + 1];
        memcpy(ptr1, ptr2, sizeof(pkgListType));
        memcpy(ptr2, ptr3, sizeof(pkgListType));
        memcpy(ptr3, ptr1, sizeof(pkgListType));
      }
    }
  }
}

int paclen;
uint8_t pkgType(const char *raw)
{
  uint8_t type = 0;
  char packettype = 0;
  const char *info_start, *body;
  paclen = strlen(raw);
  info_start = (char *)strchr(raw, ':');
  if (info_start == NULL) // IF NULL PASS ESP32 CAN BE STUCK
  {
    info_start = (char *)strchr(raw, '!');
    if (info_start == NULL) // IF NULL PASS ESP32 CAN BE STUCK
    {
      info_start = 0;
    }
    else
    {
      return 0;
    }
  }
  //
  packettype = (char)raw[0];
  body = &raw[1];

  switch (packettype)
  {
  case '=':
  case '/':
  case '@':
    if (strchr(body, 'r') != NULL)
    {
      if (strchr(body, 'g') != NULL)
      {
        if (strchr(body, 't') != NULL)
        {
          if (strchr(body, 'P') != NULL)
          {
            type = PKG_WX;
          }
        }
      }
    }
    break;
  case ':':
    type = PKG_MESSAGE;
    if (body[9] == ':' &&
        (memcmp(body + 9, ":PARM.", 6) == 0 ||
         memcmp(body + 9, ":UNIT.", 6) == 0 ||
         memcmp(body + 9, ":EQNS.", 6) == 0 ||
         memcmp(body + 9, ":BITS.", 6) == 0))
    {
      type = PKG_TELEMETRY;
    }
    break;
  case '>':
    type = PKG_STATUS;
    break;
  case '!':
    type = PKG_STATUS;
    break;
  case '?':
    type = PKG_QUERY;
    break;
  case ';':
    type = PKG_OBJECT;
    break;
  case ')':
    type = PKG_ITEM;
    break;
  case 'T':
    type = PKG_TELEMETRY;
    break;
  case '#': /* Peet Bros U-II Weather Station */
  case '*': /* Peet Bros U-I  Weather Station */
  case '_': /* Weather report without position */
    type = PKG_WX;
    break;
  default:
    type = 0;
    break;
  }
  return type;
}

void pkgListUpdate(char *call, uint8_t type)
{
  char i = pkgList_Find(call);
  time_t now;
  time(&now);
  if (i != 255)
  { // Found call in old pkg
    pkgList[(uint)i].time = now;
    pkgList[(uint)i].pkg++;
    pkgList[(uint)i].type = type;
    // Serial.print("Update: ");
  }
  else
  {
    i = pkgListOld();
    pkgList[(uint)i].time = now;
    pkgList[(uint)i].pkg = 1;
    pkgList[(uint)i].type = type;
    strcpy(pkgList[(uint)i].calsign, call);
    // strcpy(pkgList[(uint)i].ssid, &ssid[0]);
    pkgList[(uint)i].calsign[10] = 0;
    // Serial.print("NEW: ");
  }
}

bool pkgTxUpdate(const char *info, int delay)
{
  char *ecs = strstr(info, ">");
  if (ecs == NULL)
    return false;
  // Replace
  for (int i = 0; i < PKGTXSIZE; i++)
  {
    if (txQueue[i].Active)
    {
      if (!(strncmp(&txQueue[i].Info[0], info, info - ecs)))
      {
        strcpy(&txQueue[i].Info[0], info);
        txQueue[i].Delay = delay;
        txQueue[i].timeStamp = millis();
        return true;
      }
    }
  }

  // Add
  for (int i = 0; i < PKGTXSIZE; i++)
  {
    if (txQueue[i].Active == false)
    {
      strcpy(&txQueue[i].Info[0], info);
      txQueue[i].Delay = delay;
      txQueue[i].Active = true;
      txQueue[i].timeStamp = millis();
      break;
    }
  }
  return true;
}

bool pkgTxSend()
{
  for (int i = 0; i < PKGTXSIZE; i++)
  {
    if (txQueue[i].Active)
    {
      int decTime = millis() - txQueue[i].timeStamp;
      if (decTime > txQueue[i].Delay)
      {
#ifdef SA818
        // digitalWrite(POWER_PIN, config.rf_power); // RF Power LOW
#endif
        igateTLM.Tx2Rf++;
        APRS_sendTNC2Pkt(String(txQueue[i].Info)); // Send packet to RF
        txQueue[i].Active = false;
#ifdef DEBUG
        printTime();
        Serial.println("TX->RF: " + String(txQueue[i].Info));
#endif
        return true;
      }
    }
  }
  return false;
}

uint8_t *packetData;
// The function is called from ax25_decode
void aprs_msg_callback(struct AX25Msg *msg)
{
  AX25Msg pkg;
  memcpy(&pkg, msg, sizeof(AX25Msg));
  PacketBuffer.push(&pkg); // Put the package from TNC into the buffer queue.
}

void printTime()
{
  struct tm tmstruct;
  getLocalTime(&tmstruct, 5000);
  Serial.print("[");
  Serial.print(tmstruct.tm_hour);
  Serial.print(":");
  Serial.print(tmstruct.tm_min);
  Serial.print(":");
  Serial.print(tmstruct.tm_sec);
  Serial.print("]");
}

void pushGwRaw(uint8_t *raw, uint8_t size)
{
  if (gwRaw_count > PKGLISTSIZE)
    return;
  if (++gwRaw_idx_rw >= PKGLISTSIZE)
    gwRaw_idx_rw = 0;
  if (size > 65)
    size = 65;
  memcpy(&gwRaw[gwRaw_idx_rw][0], raw, size);
  gwRawSize[gwRaw_idx_rw] = size;
  gwRaw_count++;
}

uint8_t popGwRaw(uint8_t *raw)
{
  uint8_t size = 0;
  if (gwRaw_count <= 0)
    return 0;
  if (++gwRaw_idx_rd >= PKGLISTSIZE)
    gwRaw_idx_rd = 0;
  size = gwRawSize[gwRaw_idx_rd];
  memcpy(raw, &gwRaw[gwRaw_idx_rd][0], size);
  if (gwRaw_count > 0)
    gwRaw_count--;
  return size;
}

int timeHalfSec = 0;
void APRS_sendWebRequest(String MessageString, int director) // for webservice
{
  String tnc2Raw = MessageString;

  // Serial.println(MessageString);
  if (!config.aprsTracker || (config.aprsTracker && GpsOnline))
  {
    status.allCount++;
    if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
    {
      status.isCount++;
      if ((director == 0) || (director == 2))
        aprsClient.println(tnc2Raw); // APRS_sendWebRequest

      if ((director == 1) || (director == 2))
      {
        igateTLM.Tx2Rf++;
        status.TrackerCount++;
        bool DigiSend = pkgTxUpdate(tnc2Raw.c_str(), 0);
        if (!DigiSend)
        {
          status.dropCount++;
          igateTLM.DROP++;
          APRS_sendTNC2Pkt(tnc2Raw);
        }
      }
    }
    SendReset();
    if (config.oled_enable == true)
    {
      if (config.dispTNC == true)
      {
        dispBuffer.push(tnc2Raw.c_str()); // from  websend
      }
    }
  }
}

#ifdef SA818

void SA818_CHECK()
{
  while (SA818_Active == false)
  {
    if (SerialRF.available() > 0)
      SerialRF.println("AT+DMOCONNECT");
    delay(100);

    if (SerialRF.available() > 0)
    {
      String ret = SerialRF.readString();
      // Serial.println(ret);
      if (ret.indexOf("DMOCONNECT") > 0)
      {
        Serial.println("Radio SA818/SR_FRS Activated");
#ifdef DEBUG
        Serial.println(SerialRF.readString());
        Serial.println("Radio SA818/SR_FRS Activated");
#endif
        SA818_Active = true;
      }
      else
      {
        SA818_Active = false;
        Serial.println("Radio SA818/SR_FRS deActive");
        SA818_INIT(true);
        delay(500);
        SA818_CHECK();
      }
    }
  }
}

void SA818_INIT(bool boot)
{
  if (SA818_Active == false)
  {
#ifdef SR_FRS
    Serial.println("Radio Module SR_FRS Init");
#else
    Serial.println("Radio Module SA818/SA868 Init");
#endif
    if (boot)
    {
      SerialRF.begin(9600, SERIAL_8N1, 16, 17);
      SerialRF.setRxBufferSize(500);
      // pinMode(POWER_PIN, OUTPUT);
      // pinMode(PULLDOWN_PIN, OUTPUT);
      // pinMode(SQL_PIN, INPUT_PULLUP);

      // digitalWrite(POWER_PIN, LOW);
      // digitalWrite(PULLDOWN_PIN, LOW);
      // delay(500);
      // digitalWrite(PULLDOWN_PIN, HIGH);
      delay(1500);
      SerialRF.println();
      delay(500);
    }
    SerialRF.println();
    delay(500);
    char str[100];
    if (config.sql_level > 8)
      config.sql_level = 8;
#ifdef SR_FRS
    sprintf(str, "AT+DMOSETGROUP=%01d,%0.4f,%0.4f,%d,%01d,%d,0", config.band, config.freq_tx + ((float)config.offset_tx / 1000000), config.freq_rx + ((float)config.offset_rx / 1000000), config.tone_rx, config.sql_level, config.tone_tx);
    SerialRF.println(str);
    delay(500);
    // Module auto power save setting
    SerialRF.println("AT+DMOAUTOPOWCONTR=1");
    delay(500);
    SerialRF.println("AT+DMOSETVOX=0");
    delay(500);
    SerialRF.println("AT+DMOSETMIC=1,0,0");
#else
    sprintf(str, "AT+DMOSETGROUP=%01d,%0.4f,%0.4f,%04d,%01d,%04d", config.band, config.freq_tx + ((float)config.offset_tx / 1000000), config.freq_rx + ((float)config.offset_rx / 1000000), config.tone_tx, config.sql_level, config.tone_rx);
    SerialRF.println(str);
    delay(500);
    SerialRF.println("AT+SETTAIL=0");
    delay(500);
    SerialRF.println("AT+SETFILTER=1,1,1");
    delay(500);
    SerialRF.println("AT+DMOSETMIC=1,0,0");
#endif
    SerialRF.println(str);
    delay(500);
    if (config.volume > 8)
      config.volume = 8;
    SerialRF.printf("AT+DMOSETVOLUME=%d\r\n", config.volume);
  }
}
#endif

boolean APRSConnect()
{
  // Serial.println("Connect TCP Server");
  String login = "";
  int cnt = 0;
  uint8_t con = aprsClient.connected();
  // Serial.println(con);
  if (con <= 0)
  {
    if (!aprsClient.connect(config.aprs_host, config.aprs_port)) // เชื่อมต่อกับเซิร์ฟเวอร์ TCP
    {
      Serial.print(".");
      delay(100);
      cnt++;
      if (cnt > 50)
      { // request connection 50 times if not given the return function is False
        AprsConnected = false;
        Serial.println("Aprs Connection Failed");
        return false;
      }
    }
    // Connect to aprsc
    if (config.aprs_ssid == 0)
      login = "user " + String(config.aprs_mycall) + " pass " + String(config.aprs_passcode) + " vers AprsAIO V" + String(VERSION) + " filter " + String(config.aprs_filter);
    else
      login = "user " + String(config.aprs_mycall) + "-" + String(config.aprs_ssid) + " pass " + String(config.aprs_passcode) + " vers AprsAIO V" + String(VERSION) + " filter " + String(config.aprs_filter);
    aprsClient.println(login); // APRSConnect
    Serial.println(login);
    Serial.println("Aprs Connection Success");
    delay(500);
  }
  AprsConnected = true;
  return true;
}

uint8_t curTab = 0;

void setup()
{
  byte *ptr;
  pinMode(0, INPUT_PULLUP); // BOOT Button
  pinMode(LED_RX, OUTPUT);
  pinMode(LED_TX, OUTPUT);

  // Set up serial port
  Serial.begin(9600); // debug
  Serial.setRxBufferSize(256);

#ifdef SA818
#else
  SerialGPS.begin(9600, SERIAL_8N1, 16, 17);
  SerialGPS.setRxBufferSize(500);
#endif

  Serial.println();
  Serial.println("Start AprsAIO V" + String(VERSION));
  Serial.println("Push BOOT after 3 sec for Factory Default config.");

#ifdef OLED
  Wire.begin();
  Wire.setClock(400000L);

  // by default, we'll generate the high voltage from the 3.3v line internally! (neat!)
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C, false); // initialize with the I2C addr 0x3C (for the 128x64)
  // Initialising the UI will init the display too.
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(30, 5);
  display.print("ESP32 IGATE");
  display.setCursor(1, 17);
  display.print("Firmware Version " + String(VERSION));
  display.drawLine(10, 30, 110, 30, WHITE);
  display.setCursor(1, 40);
  display.print("Push B Factory reset");
  // topBar(-100);
  display.display();
#endif

  if (!EEPROM.begin(EEPROM_SIZE))
  {
    Serial.println(F("failed to initialise EEPROM")); // delay(100000);
  }

#ifdef OLED
  delay(1000);
  digitalWrite(LED_TX, HIGH);
  display.setCursor(50, 50);
  display.print("3 Sec");
  display.display();
  delay(1000);
  digitalWrite(LED_RX, HIGH);
  display.setCursor(40, 50);
  display.print("        ");
  display.display();
  display.setCursor(50, 50);
  display.print("2 Sec");
  display.display();
  delay(1000);
  display.setCursor(40, 50);
  display.print("        ");
  display.display();
  display.setCursor(50, 50);
  display.print("1 Sec");
  display.display();
#else
  delay(1000);
  digitalWrite(LED_TX, HIGH);
  delay(1000);
  digitalWrite(LED_RX, HIGH);
  delay(1000);
#endif
  if (digitalRead(0) == LOW)
  {
    defaultConfig();
    Serial.println("Manual Default configure!");
#ifdef OLED
    display.clearDisplay();
    display.setTextColor(WHITE);
    display.drawRect(2, 2, 122, 60, WHITE); // draws frame with rounded edges
    display.setCursor(22, 32);
    display.print("Factory Reset!");
    display.display();
#endif
    while (digitalRead(0) == LOW)
    {
      delay(500);
      digitalWrite(LED_TX, LOW);
      digitalWrite(LED_RX, LOW);
      delay(500);
      digitalWrite(LED_TX, HIGH);
      digitalWrite(LED_RX, HIGH);
    }
  }
  digitalWrite(LED_TX, LOW);
  digitalWrite(LED_RX, LOW);

  // checkconfig error
  ptr = (byte *)&config;
  EEPROM.readBytes(1, ptr, sizeof(Configuration));
  uint8_t chkSum = checkSum(ptr, sizeof(Configuration));
  Serial.printf("EEPROM Check %0Xh=%0Xh(%dByte)\n", EEPROM.read(0), chkSum, sizeof(Configuration));
  if (EEPROM.read(0) != chkSum)
  {
    Serial.println("Config EEPROM Error!");
    defaultConfig();
  }
  input_HPF = config.input_hpf;

#ifdef SA818
  SA818_INIT(true);
#endif

#ifdef OLED
  if (config.oled_enable == true)
  {
    display.clearDisplay();
    display.setTextSize(1);
    display.display();
  }
#endif
  showDisp = true;
  curTab = 0;
  oledSleepTimeout = millis() + (config.oled_timeout * 1000);

  if (!config.aprsTracker)
  {
    lat = config.user_lat;
    lon = config.user_lon;
  }

  // enableCore0WDT();
  enableCore1WDT();
  enableLoopWDT();

  // Task 1
  xTaskCreatePinnedToCore(
      taskAPRS,        /* Function to implement the task */
      "taskAPRS",      /* Name of the task */
      8192,            /* Stack size in words */
      NULL,            /* Task input parameter */
      1,               /* Priority of the task */
      &taskAPRSHandle, /* Task handle. */
      0);              /* Core where the task should run */

  // Task 2
  xTaskCreatePinnedToCore(
      taskNetwork,        /* Function to implement the task */
      "taskNetwork",      /* Name of the task */
      16384,              /* Stack size in words */
      NULL,               /* Task input parameter */
      1,                  /* Priority of the task */
      &taskNetworkHandle, /* Task handle. */
      1);                 /* Core where the task should run */
}

int pkgCount = 0;
float conv_coords(float in_coords)
{
  // Initialize the location.
  float f = in_coords;
  // Get the first two digits by turning f into an integer, then doing an integer divide by 100;
  // firsttowdigits should be 77 at this point.
  int firsttwodigits = ((int)f) / 100; // This assumes that f < 10000.
  float nexttwodigits = f - (float)(firsttwodigits * 100);
  float theFinalAnswer = (float)(firsttwodigits + nexttwodigits / 60.0);
  return theFinalAnswer;
}

void DD_DDDDDtoDDMMSS(float DD_DDDDD, int *DD, int *MM, int *SS)
{

  *DD = (int)DD_DDDDD;                       // made from 37.45545 this is 37 i.e. Degrees
  *MM = (int)((DD_DDDDD - *DD) * 60);        // got minutes
  *SS = ((DD_DDDDD - *DD) * 60 - *MM) * 100; // got seconds
}

String send_fix_location(bool Tracker) // BUILD SEND PACKET STRING
{
  if (!config.aprsTracker)
  {
    Tracker = false;
  }

  String tnc2Raw = "";
  int lat_dd, lat_mm, lat_ss, lon_dd, lon_mm, lon_ss;
  char strtmp[300], locx[30], locy[30];
  memset(strtmp, 0, 300);

  DD_DDDDDtoDDMMSS(lat, &lat_dd, &lat_mm, &lat_ss);
  String LatNe = "";
  if (lat_dd < 0)
  {
    LatNe = "S";
  }
  else
  {
    LatNe = "N";
  }
  lat_dd = abs(lat_dd);

  DD_DDDDDtoDDMMSS(lon, &lon_dd, &lon_mm, &lon_ss);
  String LonNe = "";
  if (lon_dd < 0)
  {
    LonNe = "W";
  }
  else
  {
    LonNe = "E";
  }
  lon_dd = abs(lon_dd);

  if (config.aprs_ssid == 0)
  {
    if (Tracker)
    {
      sprintf(strtmp, "%s>APRS07", config.aprs_mycall);
    }
    else
    {
      sprintf(strtmp, "%s>APESPG", config.aprs_mycall);
    }
  }
  else
  {
    if (Tracker)
    {
      sprintf(strtmp, "%s-%d>APRS07", config.aprs_mycall, config.aprs_ssid); // APY008
    }
    else
    {
      sprintf(strtmp, "%s-%d>APESPG", config.aprs_mycall, config.aprs_ssid);
    }
  }

  tnc2Raw = String(strtmp);

  if (config.aprs_path[0] != 0)
  {
    tnc2Raw += ",";
    tnc2Raw += String(config.aprs_path);
    tnc2Raw += ",qAC";
  }

  tnc2Raw += ":";
  tnc2Raw += "=";
  sprintf(locx, "%02d%02d.%02d", lat_dd, lat_mm, lat_ss);
  tnc2Raw += String(locx);
  tnc2Raw += String(LatNe);

  tnc2Raw += String(config.aprs_table);

  sprintf(locy, "%03d%02d.%02d", lon_dd, lon_mm, lon_ss);
  tnc2Raw += String(locy);
  tnc2Raw += String(LonNe).c_str();

  tnc2Raw += String(config.aprs_symbol);

  if (Tracker)
  {
    // M000/001/A=000149
    char Trackim[5] = "";
    sprintf(Trackim, "%03d", Trk);
    char Sspdnm[5] = "";
    sprintf(Sspdnm, "%03d", Spd);
    char Altim[10] = "";
    sprintf(Altim, "%06d", Alt);

    tnc2Raw += String(Trackim);
    tnc2Raw += "/";
    tnc2Raw += String(Sspdnm);
    tnc2Raw += "/A=";
    tnc2Raw += String(Altim);
    tnc2Raw += String(config.tnc_comment);
    if (config.AddCounter)
    {
      tnc2Raw += " /Trkr=";
      tnc2Raw += String(status.TrackerCount);
    }
  }
  else
  {
    tnc2Raw += String(config.aprs_comment);
    if (config.AddCounter)
    {
      tnc2Raw += " /Sq=";
      tnc2Raw += String(igateTLM.Sequence);
    }
  }
  return tnc2Raw;
}

int packet2Raw(String &tnc2, AX25Msg &Packet)
{
  if (Packet.len < 5)
    return 0;
  tnc2 = String(Packet.src.call);
  if (Packet.src.ssid > 0)
  {
    tnc2 += String(F("-"));
    tnc2 += String(Packet.src.ssid);
  }
  tnc2 += String(F(">"));
  tnc2 += String(Packet.dst.call);
  if (Packet.dst.ssid > 0)
  {
    tnc2 += String(F("-"));
    tnc2 += String(Packet.dst.ssid);
  }
  for (int i = 0; i < Packet.rpt_count; i++)
  {
    tnc2 += String(",");
    tnc2 += String(Packet.rpt_list[i].call);
    if (Packet.rpt_list[i].ssid > 0)
    {
      tnc2 += String("-");
      tnc2 += String(Packet.rpt_list[i].ssid);
    }
    if (Packet.rpt_flags & (1 << i))
    {
      tnc2 += "*";
    }
  }
  tnc2 += String(F(":"));
  tnc2 += String((const char *)Packet.info);
  tnc2 += String("\n");

  // #ifdef DEBUG_TNC
  //     Serial.printf("[%d] ", ++pkgTNC_count);
  //     Serial.print(tnc2);
  // #endif
  return tnc2.length();
}

int btn_count = 0;
long timeCheck = 0;

void PrintIt(double distx)
{
  Serial.print(F(" Gps_Sec="));
  Serial.print(Gps_Sec);
  Serial.print(F(" GpsOnline="));
  Serial.print(GpsOnline);
  Serial.print(F(" ready="));
  Serial.print(ready);
  Serial.print(F(" Alt ft="));
  Serial.print(Alt);
  Serial.print(F(" SpdKm="));
  Serial.print(SpdKm);
  Serial.print(F(" Trk="));
  Serial.print(Trk);
  Serial.print(F(" lat="));
  Serial.print(lat);
  Serial.print(F(" lon="));
  Serial.print(lon);
  Serial.print(F(" dist="));
  Serial.println(distx);
}

void SendReset()
{
  old_lon = lon;
  old_lat = lat;
  OldTrk = Trk;
  ready = false;
  sendTimeX = millis();
  // Serial.println(F("SendReset"));
}

bool AFSKInitAct = true;
long blank;

void loop()
{
  vTaskDelay(10 / portTICK_PERIOD_MS);

  if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
  {
    TrackDelay = 6000;
  }
  else
  {
    TrackDelay = 15000;
  }

  if (config.aprsTracker)
  {
    while (SerialGPS.available() > 0)
    {
      gps.encode(SerialGPS.read());
    }

    double Lati = gps.location.lat();
    double Loni = gps.location.lng();
    Gps_Sec = gps.time.second();

    if (Gps_Sec != Old_GpsSec)
    {
      if ((Lati != 0) && (Loni != 0))
      {
        if (gps.altitude.isUpdated() || gps.satellites.isUpdated() ||
            pdop.isUpdated() || hdop.isUpdated() || vdop.isUpdated())
        {
          GpsOnline = true;
          lat = Lati;
          lon = Loni;
          if (old_lat == 0 && lat != 0)
            old_lat = lat;
          if (old_lon == 0 && lon != 0)
            old_lon = lon;
          Spd = gps.speed.knots();
          SpdKm = gps.speed.kmph();
          Alt = gps.altitude.feet();
          Trk = gps.course.deg();
          distxy = int(aprsParse.distance(old_lon, old_lat, lon, lat) * 1000); // meters
        }
        else
        {
          TrackTimer = 3600;
        }
      }
      else
      {
        TrackTimer = 3600;
      }
    }
    else
    {
      TrackTimer = 3600;
    }

    if (millis() > SerDelay + 1100)
    {
      Old_GpsSec = Gps_Sec;
      SerDelay = millis();

      if (GpsOnline)
      {
        // PrintIt(distxy);
      }
#ifdef SA818
      if (SA818_Active == false)
        SA818_CHECK();
#endif
    }

    if (SpdKm < 10)
    {
      if (distxy < 25)
      {
        moving = false;
        TrackTimer = 594;
      }
      else
      {
        if (SpdKm <= 3)
        {
          moving = false;
          TrackTimer = 3600;
        }
        else if (SpdKm > 3)
        {
          moving = true;
          TrackTimer = 114;
        }
      }
    }
    else
    {
      if (distxy < 25)
      {
        moving = false;
        TrackTimer = 174;
      }
      else
      {
        moving = true;
        int DeltaTrigger = int(10 * cosf((SpdKm * PI) / 180.0f) + 2);

        if (DeltaTrigger < 3)
          DeltaTrigger = 3;
        else if (DeltaTrigger > 12)
          DeltaTrigger = 12;

        int DeltaAngle = abs(Trk - OldTrk);
        if (DeltaAngle > 180)
          DeltaAngle = abs(360 - DeltaAngle);

        if (DeltaAngle > DeltaTrigger)
        {
          ready = true;
          TrackTimer = 1;
        }
        else
        {
          TrackTimer = 84;
          ready = false;
        }
      }
    }

    if (moving)
    {
      StopSend = true;
    }

    if (!moving && StopSend)
    {
      ready = true;
      TrackTimer = 1;
      TrackDelay = 6000;
      StopSend = false;
    }
  }
  else
  {
    GpsOnline = false;
    lat = config.user_lat;
    lon = config.user_lon;
  }

#ifdef OLED
  // Popup Display
  if (config.oled_enable == true)
  {

    if (showDisp)
    {
      showDisp = false;
      display.clearDisplay();
      display.display();
      oledSleepTimeout = millis() + (config.dispDelay * 1000);

      switch (curTab)
      {
      case 0:
        userDisp();
        break;
      case 1:
        blankDisp();
        break;
      case 2:
        statisticsDisp();
        break;
      case 3:
        pkgLastDisp();
        break;
      case 4:
        pkgCountDisp();
        break;
      case 5:
        systemDisp();
        break;
      }
      delay(500);
    }

    if (dispBuffer.getCount() > 0)
    {
      if (curTab != 1)
      {
        if (millis() > timeHalfSec)
        {
          display.clearDisplay();
          display.display();
          char tnc2[300];
          dispBuffer.pop(&tnc2);
          dispWindow(String(tnc2), 0, true);
        }
      }
    }
    else
    {
      // Sleep display
      if (millis() > timeHalfSec)
      {
        if (timeHalfSec > 0)
        {
          timeHalfSec = 0;
          oledSleepTimeout = millis() + (config.oled_timeout * 1000);
        }
        else
        {
          if (millis() > oledSleepTimeout && oledSleepTimeout > 0)
          {
            oledSleepTimeout = 0;
            display.clearDisplay();
            display.display();
          }
        }
      }
    }
  }
#endif

  if (millis() > timeCheck)
  {
    timeCheck = millis() + 30000;

    if (ESP.getFreeHeap() < 60000)
    {
      // Serial.print("ESP.getFreeHeap: ");
      // Serial.println(String(ESP.getFreeHeap()));
    }
    else if (ESP.getFreeHeap() < 40000)
    {
      esp_restart(); // RESTART
    }
  }

#ifdef SA818
  // if (SerialRF.available())
  // {
  //     Serial.print(Serial.readString());
  // }
#endif

  if (AFSKInitAct == true)
  {
#ifdef SA818
    AFSK_Poll(false, config.rf_power);
#else
    AFSK_Poll(true, LOW);
#endif
  }
}

void TrackerSend() // APRS TRACKER
{
  if (millis() > (sendTimeX + (TrackTimer * 1000) + TrackDelay))
  {
    if (config.aprsTracker && GpsOnline)
    {
      String tnc2Raw = send_fix_location(true);
      status.allCount++; // TrackerSend
      if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
      {
        status.isCount++;
        aprsClient.println(tnc2Raw); // TrackerSend
      }
      else if (config.tnc && config.tnc_digi)
      {
        igateTLM.Tx2Rf++;
        status.TrackerCount++;
        bool DigiSend = pkgTxUpdate(tnc2Raw.c_str(), 0);
        if (!DigiSend)
        {
          status.dropCount++;
          igateTLM.DROP++;
          APRS_sendTNC2Pkt(tnc2Raw);
        }
      }
      sendTimer = millis();
      SendReset();
    }
  }
}

String sendIsAckMsg(String toCallSign, int msgId)
{
  char str[300];
  char call[11];
  int i;
  memset(&call[0], 0, 11);
  sprintf(call, "%s-%d", config.aprs_mycall, config.aprs_ssid);
  strcpy(&call[0], toCallSign.c_str());
  i = strlen(call);
  for (; i < 9; i++)
    call[i] = 0x20;
  memset(&str[0], 0, 300);

  sprintf(str, "%s-%d>APESPG%s::%s:ack%d", config.aprs_mycall, config.aprs_ssid, VERSION, call, msgId);

  aprsClient.println(str); // sendIsAckMsg
  return String(str);
}

void sendIsPkg(char *raw) // SEND TELEMETERS TO APRS IS
{
  char str[300];
  sprintf(str, "%s-%d>APESPG%s:%s", config.aprs_mycall, config.aprs_ssid, VERSION, raw);

  String tnc2Raw = String(str);
  if (!config.aprsTracker || (config.aprsTracker && GpsOnline))
  {
    status.allCount++; // sendIsPkg
    if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
    {
      status.isCount++;
      aprsClient.println(tnc2Raw); // sendIsPkg
    }
    else if (config.tnc && config.tnc_digi)
    {
      igateTLM.Tx2Rf++;
      status.digi++;
      bool DigiSend = pkgTxUpdate(tnc2Raw.c_str(), 0);
      if (!DigiSend)
      {
        status.dropCount++;
        igateTLM.DROP++;
        APRS_sendTNC2Pkt(tnc2Raw);
      }
    }
  }
}

void sendIsPkgMsg(char *raw) // OWN TELEMETER SEND to iNET or RF
{
  char str[300];
  char call[11];
  int i;
  memset(&call[0], 0, 11);
  if (config.aprs_ssid == 0)
    sprintf(call, "%s", config.aprs_mycall);
  else
    sprintf(call, "%s-%d", config.aprs_mycall, config.aprs_ssid);

  i = strlen(call);

  for (; i < 9; i++)
    call[i] = 0x20;

  if (config.aprs_ssid == 0)
    sprintf(str, "%s>APESPG::%s:%s", config.aprs_mycall, call, raw);
  else
    sprintf(str, "%s-%d>APESPG::%s:%s", config.aprs_mycall, config.aprs_ssid, call, raw);

  if (!config.aprsTracker || (config.aprsTracker && GpsOnline))
  {
    String tnc2Raw = String(str);
    status.allCount++; // sendIsPkgMsg
    if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
    {
      status.isCount++;
      aprsClient.println(tnc2Raw); // sendIsPkgMsg
    }
    else if (config.tnc && config.tnc_digi)
    {
      status.digi++;
      bool DigiSend = pkgTxUpdate(str, 0);
      if (!DigiSend)
      {
        status.dropCount++;
        igateTLM.DROP++;
        APRS_sendTNC2Pkt(tnc2Raw);
      }
    }
  }
}

long timeSlot;
void taskAPRS(void *pvParameters)
{
  //	long start, stop;
  // char *raw;
  // char *str;
  Serial.println("Task APRS has been start");
  PacketBuffer.clean();

  APRS_init();
  APRS_setCallsign(config.aprs_mycall, config.aprs_ssid);

  if (config.aprs_dest[0] != 0)
  {
    APRS_setDestination(config.aprs_dest, 0);
  }
  else
  {
    sprintf(config.aprs_dest, "APESPG");
    APRS_setDestination(config.aprs_dest, 0);
  }

  if (config.aprs_msgdest[0] != 0)
  {
    APRS_setMessageDestination(config.aprs_msgdest, config.aprs_msgdestssid);
  }

  char path1[72];
  char path2[72];
  sprintf(path1, "WIDE1");
  sprintf(path2, "WIDE2");
  APRS_setPath1(path1, 1);
  APRS_setPath2(path2, 1);
  APRS_setPreamble(300);
  APRS_setTail(0);

  sendTimer = millis() + 30000;
  // sendTimer = millis() - (config.aprs_beacon * 1000) + 30000;
  igateTLM.TeleTimeout = millis() + 60000; // 1Min
  timeSlot = millis() + 1000;

  for (;;) // taskAPRS // IGate : RF->INET
  {
    vTaskDelay(20 / portTICK_PERIOD_MS);
    long now = millis();
    // wdtSensorTimer = now;
    time_t timeStamp;
    time(&timeStamp);
    // serviceHandle();

    if (!config.aprsTracker || (config.aprsTracker && GpsOnline))
    {
      if (config.tnc) // IGate : RF->INET
      {
        if (PacketBuffer.getCount() > 0)
        {
          // IGate Process
          if (PacketBuffer.pop(&incomingPacket))
          {
            String tnc2;
            packet2Raw(tnc2, incomingPacket);

            if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
            {
              if (config.rf2inet)
              {
                status.allCount++; // incomingPacket  RF->INET
                status.tncCount++;

                int ret = igateProcess(incomingPacket);
                if (ret == 0)
                {
                  status.dropCount++;
                  igateTLM.DROP++;
                  aprsClient.println(tnc2); // taskAPRS
                }
                else
                {
                  status.rf2inet++;
                  igateTLM.RF2INET++;

                  //

                  /*
                  char call[11];
                  if (incomingPacket.src.ssid > 0)
                   sprintf(call, "%s-%d", incomingPacket.src.call, incomingPacket.src.ssid);
                   else
                   sprintf(call, "%s", incomingPacket.src.call);
                   uint8_t type = pkgType((char *)incomingPacket.info);
                   pkgListUpdate(call, type);
                  */
#ifdef DEBUG
                  printTime();
                  Serial.print("RF->INET: ");
                  Serial.println(tnc2);
#endif
                }
              }
              if (config.FeedBack)
              {
                status.digi++;
                bool DigiSend = pkgTxUpdate(tnc2.c_str(), digiDelay);
                if (!DigiSend)
                {
                  status.dropCount++;
                  igateTLM.DROP++;
                  APRS_sendTNC2Pkt(tnc2);
                }
              }
            }
            else if (config.tnc_digi) // Digi Repeater Process
            {
              char call[11];
              if (incomingPacket.src.ssid > 0)
                sprintf(call, "%s-%d", incomingPacket.src.call, incomingPacket.src.ssid);
              else
                sprintf(call, "%s", incomingPacket.src.call);

              uint8_t type = pkgType((char *)incomingPacket.info);
              pkgListUpdate(call, type);

              int dlyFlag = digiProcess(incomingPacket);

              if (dlyFlag > 0)
              {
                igateTLM.DigiRpt++;
                int digiDelay;
                if (dlyFlag == 1)
                {
                  digiDelay = 0;
                }
                else
                {
                  if (config.digi_delay == 0)
                  { // Auto mode
                    if (digiCount > 20)
                      digiDelay = random(5000);
                    else if (digiCount > 10)
                      digiDelay = random(3000);
                    else if (digiCount > 0)
                      digiDelay = random(1500);
                    else
                      digiDelay = random(500);
                  }
                  else
                  {
                    digiDelay = random(config.digi_delay);
                  }

                  status.digi++;
                  bool DigiSend = pkgTxUpdate(tnc2.c_str(), digiDelay);
                  if (!DigiSend)
                  {
                    status.dropCount++;
                    igateTLM.DROP++;
                    APRS_sendTNC2Pkt(tnc2);
                  }
                }
              }
              else
              {
                igateTLM.DROP++;
                status.dropCount++;
              }
            }
            lastPkg = true;
            lastPkgRaw = tnc2;

            if (config.oled_enable == true)
            {
              if (config.dispTNC == true)
              {
                dispBuffer.push(tnc2.c_str()); // from  dispTNC : from RF
              }
            }
          }
        }
      }

      if (now > (sendTimer + (config.aprs_beacon * 1000)))
      {
        sendTimer = now;
        if (digiCount > 0)
          digiCount--;
#ifdef SA818
        if (SA818_Active == false)
          SA818_CHECK();
#endif
        String tnc2Raw = send_fix_location(true);
        status.allCount++; // aprs_beacon
        if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
        {
          status.isCount++;
          aprsClient.println(tnc2Raw); // aprs_beacon
        }
        else
        {
          igateTLM.Tx2Rf++;
          status.TrackerCount++;
          bool DigiSend = pkgTxUpdate(tnc2Raw.c_str(), 0);
          if (!DigiSend)
          {
            status.dropCount++;
            igateTLM.DROP++;
            APRS_sendTNC2Pkt(tnc2Raw);
          }
        }
      }
      else if (ready)
      {
        TrackerSend();
      }

      if (now > (timeSlot + 10))
      {
        if (!digitalRead(LED_PIN))
        { // RX State Fail
          if (pkgTxSend())
            timeSlot = millis() + config.tx_timeslot; // Tx Time Slot = 5sec.
          else
            timeSlot = millis();
        }
        else
        {
          timeSlot = millis() + 200;
        }
      }

      if (millis() > igateTLM.TeleTimeout)
      {
        igateTLM.TeleTimeout = millis() + 600000; // 10Min
        if (config.tnc_telemetry)
        {
          if ((igateTLM.Sequence % 6) == 0)
          {
            sendIsPkgMsg((char *)&PARM[0]);
            sendIsPkgMsg((char *)&UNIT[0]);
            sendIsPkgMsg((char *)&EQNS[0]);
          }
          char rawTlm[100];
          if (config.aprs_ssid == 0)
            sprintf(rawTlm, "%s>APESPG:T#%03d,%d,%d,%d,%d,%d,00000000", config.aprs_mycall, igateTLM.Sequence, igateTLM.RF2INET, igateTLM.INET2RF, igateTLM.DigiRpt, igateTLM.Tx2Rf, igateTLM.DROP);
          else
            sprintf(rawTlm, "%s-%d>APESPG:T#%03d,%d,%d,%d,%d,%d,00000000", config.aprs_mycall, config.aprs_ssid, igateTLM.Sequence, igateTLM.RF2INET, igateTLM.INET2RF, igateTLM.DigiRpt, igateTLM.Tx2Rf, igateTLM.DROP);

          if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
          {
            status.isCount++;
            aprsClient.println(String(rawTlm)); // config.tnc_telemetry
          }
          else if (config.tnc && config.tnc_digi)
          {
            igateTLM.Tx2Rf++;
            status.TrackerCount++;
            bool DigiSend = pkgTxUpdate(rawTlm, digiDelay);
            if (!DigiSend)
            {
              status.dropCount++;
              igateTLM.DROP++;
              APRS_sendTNC2Pkt(String(rawTlm));
            }
          }

          igateTLM.Sequence++;
          if (igateTLM.Sequence > 999)
          {
            igateTLM.Sequence = 0;
          }
          igateTLM.RF2INET = 0;
          igateTLM.INET2RF = 0;
          igateTLM.DigiRpt = 0;
          igateTLM.Tx2Rf = 0;
          igateTLM.DROP = 0;
          // client.println(raw);
        }
      }
    }

    if (digitalRead(0) == LOW)
    {
      btn_count++;
      // Serial.println(btn_count);
      if (btn_count > 1000) // Push BOOT 10sec
      {
        digitalWrite(LED_PIN, HIGH);
        digitalWrite(LED_TX_PIN, HIGH);
      }
    }
    else
    {
      if (btn_count > 1000) // Push BOOT 10sec to Factory Default
      {
        digitalWrite(LED_RX, LOW);
        digitalWrite(LED_TX, LOW);
        defaultConfig();
        Serial.println("SYSTEM REBOOT NOW!");
        esp_restart();
      }
      else if (btn_count > 50)
      {
        if (!config.aprsTracker || (config.aprsTracker && GpsOnline))
        {
          if (config.tnc)
          {
            String tnc2Raw;
            if (GpsOnline)
            {
              tnc2Raw = send_fix_location(true);
            }
            else
            {
              tnc2Raw = send_fix_location(false);
            }
            status.allCount++; // btn_count > 50
            if (aprsClient.connected() && (WiFi.status() == WL_CONNECTED))
            {
              status.isCount++;
              aprsClient.println(tnc2Raw); // btn_count > 50
            }
            if (config.tnc_digi)
            {
              igateTLM.Tx2Rf++;
              status.TrackerCount++;
              bool DigiSend = pkgTxUpdate(tnc2Raw.c_str(), digiDelay);
              if (!DigiSend)
              {
                status.dropCount++;
                igateTLM.DROP++;
                APRS_sendTNC2Pkt(tnc2Raw);
              }
            }
            SendReset();
            if (config.oled_enable == true)
            {
              if (config.dispTNC == true)
              {
                dispBuffer.push(tnc2Raw.c_str()); // from  buttonsend
              }
            }
          }
        }
      }
      else if (btn_count > 0)
      {
        curTab++;
        if (curTab > 5)
          curTab = 0;
        showDisp = true;
      }
      btn_count = 0;
    }

#ifdef SA818
    SA818_CHECK();
#endif
#ifdef SA818
// if(digitalRead(SQL_PIN)==HIGH){
// 	delay(10);
// 	if(digitalRead(SQL_PIN)==LOW){
// 		while(SerialRF.available()) SerialRF.read();
// 		SerialRF.println("RSSI?");
// 		delay(100);
// 		String ret=SerialRF.readString();
// 		Serial.println(ret);
// 		if(ret.indexOf("RSSI=")>=0){
// 			String sig=getValue(ret,'=',2);
// 			Serial.printf("SIGNAL %s\n",sig.c_str());
// 		}
// 	}
// }
#endif
  }
}

int mqttRetry = 0;
long wifiTTL = 0;

void taskNetwork(void *pvParameters)
{
  int c = 0;
  Serial.println("Task Network has been start");

  if (config.wifi_mode == WIFI_AP_STA_FIX || config.wifi_mode == WIFI_AP_FIX)
  {
    if (config.wifi_mode == WIFI_AP_STA_FIX)
    {
      WiFi.mode(WIFI_AP_STA);
      // Serial.println(F("WIFI_AP_STA"));
    }
    else if (config.wifi_mode == WIFI_AP_FIX)
    {
      WiFi.mode(WIFI_AP);
      // Serial.println(F("WIFI_AP"));
    }
    // Configure Wi-Fi functionality as an access point.
    WiFi.softAP(config.wifi_ap_ssid, config.wifi_ap_pass); // Start HOTspot removing password will disable security
    WiFi.softAPConfig(local_IP, gateway, subnet);
    Serial.print("Access point running. IP address: ");
    Serial.print(WiFi.softAPIP());
    Serial.println("");
  }
  else if (config.wifi_mode == WIFI_STA_FIX)
  {
    WiFi.mode(WIFI_STA);
    Serial.println(F("WIFI_STA"));
    WiFi.disconnect();
    delay(100);
    Serial.println(F("WiFi Station Only mode."));
  }
  else
  {
    WiFi.mode(WIFI_OFF);
    Serial.println(F("WIFI_OFF"));
    WiFi.disconnect(true);
    delay(100);
    Serial.println(F("WiFi OFF All mode."));
    // SerialBT.begin("APRS AIO",false);//TA1AYH BT
  }

  webService();
  pingTimeout = millis() + 10000;

  for (;;)
  {
    vTaskDelay(10 / portTICK_PERIOD_MS);
    serviceHandle();
    // wdtNetworkTimer = millis();
    if (config.wifi_mode == WIFI_AP_STA_FIX || config.wifi_mode == WIFI_STA_FIX)
    {
      if (WiFi.status() != WL_CONNECTED)
      {
        unsigned long int tw = millis();
        if (tw > wifiTTL)
        {
#ifndef I2S_INTERNAL
          AFSK_TimerEnable(false);
#endif
          wifiTTL = tw + 60000;
          Serial.println("WiFi connecting..");
          // udp.endPacket();
          WiFi.disconnect();
          WiFi.setTxPower((wifi_power_t)config.wifi_power);
#ifdef SA818
          WiFi.setHostname("AprsAIO-818");
#else
          WiFi.setHostname("AprsAIO");
#endif
          WiFi.begin(config.wifi_ssid, config.wifi_pass);
          if (config.vpn)
            wireguard_remove();
          // Wait up to 1 minute for connection...
          for (c = 0; (c < 30) && (WiFi.status() != WL_CONNECTED); c++)
          {
            // Serial.write('.');
            if (ready){
              TrackerSend();
            }
            vTaskDelay(1000 / portTICK_PERIOD_MS);

            // for (t = millis(); (millis() - t) < 1000; refresh());
          }
          if (c >= 30)
          { // If it didn't connect within 1 min
            Serial.println("Failed. Will retry...");
            WiFi.disconnect();
            // WiFi.mode(WIFI_OFF);
            if (ready)
            {
              TrackerSend();
            }
            vTaskDelay(3000 / portTICK_PERIOD_MS);
            config.wifi_mode = WIFI_AP_STA_FIX;
            WiFi.mode(WIFI_AP_STA);
            // WiFi.mode(WIFI_STA);
            WiFi.reconnect();
            continue;
          }

          Serial.println("WiFi connected");
          Serial.print("IP address: ");
          Serial.println(WiFi.localIP());

          vTaskDelay(1000 / portTICK_PERIOD_MS);
          NTP_Timeout = millis() + 5000;
// Serial.println("Contacting Time Server");
// configTime(3600 * timeZone, 0, "aprs.dprns.com", "1.pool.ntp.org");
// vTaskDelay(3000 / portTICK_PERIOD_MS);
#ifndef I2S_INTERNAL
          AFSK_TimerEnable(true);
#endif
        }
      }
      else
      {
        if (millis() > NTP_Timeout)
        {
          NTP_Timeout = millis() + 86400000;
          // Serial.println("Config NTP");
          // setSyncProvider(getNtpTime);
          Serial.println("Contacting Time Server");
          configTime(3600 * config.timeZone, 0, "203.150.19.26", "110.170.126.101", "77.68.122.252");

          vTaskDelay(3000 / portTICK_PERIOD_MS);
          time_t systemTime;
          time(&systemTime);
          setTime(systemTime);
          if (systemUptime == 0)
          {
            systemUptime = now();
            Serial.println("Time Server Syncronized !");
          }
          if (config.vpn)
          {
            if (!wireguard_active())
            {
              // Serial.println("Setup Wiregurad VPN!");
              wireguard_setup();
            }
          }
        }

        if (config.aprs)
        {
          if (AprsConnected == false)
          {
            APRSConnect();
          }
          else
          {
            if (!config.aprsTracker || (config.aprsTracker && GpsOnline))
              APRSIS(); // START LISTENING iNET TO PACKET
          }
        }

        if (millis() > pingTimeout)
        {
          pingTimeout = millis() + 300000;
          Serial.println("Ping GW to " + WiFi.gatewayIP().toString());
          if (ping_start(WiFi.gatewayIP(), 3, 0, 0, 5) == true)
          {
            Serial.println("GW Success!!");
          }
          else
          {
            Serial.println("GW Fail!");
            WiFi.disconnect();
            wifiTTL = 0;
          }

          if (config.vpn)
          {
            IPAddress vpnIP;
            vpnIP.fromString(String(config.wg_gw_address));
            Serial.println("Ping VPN to " + vpnIP.toString());
            if (ping_start(vpnIP, 2, 0, 0, 10) == true)
            {
              Serial.println("VPN Ping Success!!");
            }
            else
            {
              Serial.println("VPN Ping Fail!");
              wireguard_remove();
              delay(3000);
              wireguard_setup();
            }
          }
        }
      }
    }
  }
}

void APRSIS() // LISTENING iNET to Packet
{
  String line = aprsClient.readStringUntil('\n'); // read the value Server Answer each line
  int start_val = line.indexOf(">", 0);           // find the first position of >

  if (start_val > 3)
  {
    // char *raw = (char *)malloc(line.length() + 1);
    String src_call = line.substring(0, start_val);
    String msg_call = "::" + src_call;

    if (config.tnc && config.inet2rf)
    {
      if (line.indexOf(msg_call) <= 0) // src callsign = msg callsign  not telemetry topic
      {
        if (line.indexOf(":T#") < 0) // not a telemetry message
        {
          status.allCount++;
          if (line.indexOf("::") > 0) // text only
          {                           // message only
                                      // raw[0] = '}';
                                      // line.toCharArray(&raw[1], line.length());
                                      // tncTxEnable = false;
                                      // SerialTNC.flush();
                                      // Serial.print("raw: ");
                                      // Serial.println(raw);
                                      // printTime();
            status.inet2rf++;
            igateTLM.INET2RF++;
            bool DigiSend = pkgTxUpdate(line.c_str(), 0);
            if (!DigiSend)
            {
              status.dropCount++;
              igateTLM.DROP++;
              APRS_sendTNC2Pkt(line);
            }
#ifdef DEBUG
            Serial.print("INET->RF ");
            Serial.println(line);
#endif
          }
          else if (status.inet2rf)
          {
            status.inet2rf++;
            igateTLM.INET2RF++;
            bool DigiSend = pkgTxUpdate(line.c_str(), 0);
            if (!DigiSend)
            {
              status.dropCount++;
              igateTLM.DROP++;
              APRS_sendTNC2Pkt(line);
            }
          }
        }
      }
      else
      {
        igateTLM.DROP++;
        status.dropCount++;
        // Serial.print("INET Message TELEMETRY from ");
        // Serial.println(src_call);
        // Serial.println(line);
      }
    }

    if (config.oled_enable == true)
    {
      if (config.dispINET == true)
      {
        if (curTab != 1)
        {
          dispBuffer.push(line.c_str()); // from dispINET from inet
        }
      }
    }
  }
}

// Routine
void line_angle(signed int startx, signed int starty, unsigned int length, unsigned int angle, unsigned int color)
{
  display.drawLine(startx, starty, (startx + length * cosf(angle * 0.017453292519)), (starty + length * sinf(angle * 0.017453292519)), color);
}

int xSpiGlcdSelFontHeight = 8;
int xSpiGlcdSelFontWidth = 5;

void compass_label(signed int startx, signed int starty, unsigned int length, double angle, unsigned int color)
{
  double angleNew;
  // ushort Color[2];
  uint8_t x_N, y_N, x_S, y_S;
  int x[4], y[4], i;
  int xOffset, yOffset;
  yOffset = (xSpiGlcdSelFontHeight / 2);
  xOffset = (xSpiGlcdSelFontWidth / 2);
  // GLCD_WindowMax();
  angle += 270.0F;
  angleNew = angle;
  for (i = 0; i < 4; i++)
  {
    if (angleNew > 360.0F)
      angleNew -= 360.0F;
    x[i] = startx + (length * cosf(angleNew * 0.017453292519));
    y[i] = starty + (length * sinf(angleNew * 0.017453292519));
    x[i] -= xOffset;
    y[i] -= yOffset;
    angleNew += 90.0F;
  }
  angleNew = angle + 45.0F;
  for (i = 0; i < 4; i++)
  {
    if (angleNew > 360.0F)
      angleNew -= 360.0F;
    x_S = startx + ((length - 3) * cosf(angleNew * 0.017453292519));
    y_S = starty + ((length - 3) * sinf(angleNew * 0.017453292519));
    x_N = startx + ((length + 3) * cosf(angleNew * 0.017453292519));
    y_N = starty + ((length + 3) * sinf(angleNew * 0.017453292519));
    angleNew += 90.0F;
    display.drawLine(x_S, y_S, x_N, y_N, color);
  }
  display.drawCircle(startx, starty, length, color);
  display.setFont();
  display.drawChar((uint8_t)x[0], (uint8_t)y[0], 'N', WHITE, BLACK, 1);
  display.drawChar((uint8_t)x[1], (uint8_t)y[1], 'E', WHITE, BLACK, 1);
  display.drawChar((uint8_t)x[2], (uint8_t)y[2], 'S', WHITE, BLACK, 1);
  display.drawChar((uint8_t)x[3], (uint8_t)y[3], 'W', WHITE, BLACK, 1);
}

void compass_arrow(signed int startx, signed int starty, unsigned int length, double angle, unsigned int color)
{
  double angle1, angle2;
  int xdst, ydst, x1sta, y1sta, x2sta, y2sta;
  int length2 = length / 2;
  angle += 270.0F;
  if (angle > 360.0F)
    angle -= 360.0F;
  xdst = startx + length * cosf(angle * 0.017453292519);
  ydst = starty + length * sinf(angle * 0.017453292519);
  angle1 = angle + 135.0F;
  if (angle1 > 360.0F)
    angle1 -= 360.0F;
  angle2 = angle + 225.0F;
  if (angle2 > 360.0F)
    angle2 -= 360.0F;
  x1sta = startx + length2 * cosf(angle1 * 0.017453292519);
  y1sta = starty + length2 * sinf(angle1 * 0.017453292519);
  x2sta = startx + length2 * cosf(angle2 * 0.017453292519);
  y2sta = starty + length2 * sinf(angle2 * 0.017453292519);
  display.drawLine(startx, starty, xdst, ydst, color);
  display.drawLine(xdst, ydst, x1sta, y1sta, color);
  display.drawLine(x1sta, y1sta, startx, starty, color);
  display.drawLine(startx, starty, x2sta, y2sta, color);
  display.drawLine(x2sta, y2sta, xdst, ydst, color);
}

const char *directions[] = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

void dispWindow(String line, uint8_t mode, bool filter)
{
  // uint16_t bgcolor, txtcolor;
  bool Monitor = false;
  char text[200];
  unsigned char x = 0;
  char itemname[10];
  int start_val = line.indexOf(">", 0); // first rank >

  if (start_val > 3)
  {
    // Serial.println(line);
    String src_call = line.substring(0, start_val);
    memset(&aprs, 0, sizeof(pbuf_t));
    aprs.buf_len = 300;
    aprs.packet_len = line.length();
    line.toCharArray(&aprs.data[0], aprs.packet_len);
    int start_info = line.indexOf(":", 0);
    int end_ssid = line.indexOf(",", 0);
    int start_dst = line.indexOf(">", 2);
    int start_dstssid = line.indexOf("-", start_dst);
    if ((start_dstssid > start_dst) && (start_dstssid < start_dst + 10))
    {
      aprs.dstcall_end_or_ssid = &aprs.data[start_dstssid];
    }
    else
    {
      aprs.dstcall_end_or_ssid = &aprs.data[end_ssid];
    }
    aprs.info_start = &aprs.data[start_info + 1];
    aprs.dstname = &aprs.data[start_dst + 1];
    aprs.dstname_len = end_ssid - start_dst;
    aprs.dstcall_end = &aprs.data[end_ssid];
    aprs.srccall_end = &aprs.data[start_dst];

    // Serial.println(aprs.info_start);
    // aprsParse.parse_aprs(&aprs);
    if (aprsParse.parse_aprs(&aprs))
    {
      if (filter == true)
      {
        if (config.filterStatus && (aprs.packettype & T_STATUS))
        {
          Monitor = true;
        }
        else if (config.filterMessage && (aprs.packettype & T_MESSAGE))
        {
          Monitor = true;
        }
        else if (config.filterTelemetry && (aprs.packettype & T_TELEMETRY))
        {
          Monitor = true;
        }
        else if (config.filterWeather && (aprs.packettype & T_WX))
        {
          Monitor = true;
        }
        else if (config.filterPosition && (aprs.packettype & T_POSITION))
        {
          if (config.filterDistant == 0)
          {
            Monitor = true;
          }
          else
          {
            double dist = aprsParse.distance(lon, lat, aprs.lng, aprs.lat);
            if (dist < config.filterDistant)
              Monitor = true;
            else
              Monitor = false;
          }
        }
        else if (config.filterTracker && (aprs.packettype & T_POSITION))
        {
          if (aprs.flags & F_CSRSPD)
          {
            double dist = aprsParse.distance(lon, lat, aprs.lng, aprs.lat);
            if (config.filterDistant == 0)
            {
              Monitor = true;
            }
            else
            {
              if (dist < config.filterDistant)
                Monitor = true;
              else
                Monitor = false;
            }
          }
        }
        else if (config.filterMove && (aprs.packettype & T_POSITION))
        {
          if (aprs.flags & F_CSRSPD)
          {
            if (aprs.speed > 0)
            {
              double dist = aprsParse.distance(lon, lat, aprs.lng, aprs.lat);
              if (config.filterDistant == 0)
              {
                Monitor = true;
              }
              else
              {
                if (dist < config.filterDistant)
                  Monitor = true;
                else
                  Monitor = false;
              }
            }
          }
        }
      }
      dispPush = 0;
    }

    if (Monitor)
    {
      Monitor = false;
      if (dispPush)
      {
        disp_delay = config.oled_timeout * 1000;
        display.drawRoundRect(0, 0, 128, 16, 5, WHITE);
      }
      else
      {
        disp_delay = config.dispDelay * 1000;
      }
      timeHalfSec = millis() + disp_delay;
      // display.fillRect(0, 0, 128, 16, WHITE);
      const uint8_t *ptrSymbol;
      uint8_t symIdx = aprs.symbol[1] - 0x21;
      if (symIdx > 95)
        symIdx = 0;
      if (aprs.symbol[0] == '/')
      {
        ptrSymbol = &Icon_TableA[symIdx][0];
      }
      else if (aprs.symbol[0] == '\\')
      {
        ptrSymbol = &Icon_TableB[symIdx][0];
      }
      else
      {
        if (aprs.symbol[0] < 'A' || aprs.symbol[0] > 'Z')
        {
          aprs.symbol[0] = 'N';
          aprs.symbol[1] = '&';
          symIdx = 5; // &
        }
        ptrSymbol = &Icon_TableB[symIdx][0];
      }
      display.drawYBitmap(0, 0, ptrSymbol, 16, 16, WHITE);
      if (!(aprs.symbol[0] == '/' || aprs.symbol[0] == '\\'))
      {
        display.drawChar(5, 4, aprs.symbol[0], BLACK, WHITE, 1);
        display.drawChar(6, 5, aprs.symbol[0], BLACK, WHITE, 1);
      }
      display.setCursor(20, 7);
      display.setTextSize(1);
      display.setFont(&FreeSansBold9pt7b);

      if (aprs.srcname_len > 0)
      {
        memset(&itemname, 0, sizeof(itemname));
        memcpy(&itemname, aprs.srcname, aprs.srcname_len);
        // Serial.println(itemname);
        display.print(itemname);
      }
      else
      {
        display.print(src_call);
      }

      display.setFont();
      display.setTextColor(WHITE);
      // if(selTab<10)
      // 	display.setCursor(121, 0);
      // else
      // 	display.setCursor(115, 0);
      // display.print(selTab);

      if (mode == 1)
      {
        display.drawRoundRect(0, 16, 128, 48, 5, WHITE);
        display.fillRoundRect(1, 17, 126, 10, 2, WHITE);
        display.setTextColor(BLACK);
        display.setCursor(40, 18);
        display.print("TNC2 RAW");

        display.setFont();
        display.setCursor(2, 30);
        display.setTextColor(WHITE);
        display.print(line);

        display.display();
        return;
      }

      if (aprs.packettype & T_TELEMETRY)
      {
        bool show = false;
        int idx = tlmList_Find((char *)src_call.c_str());
        if (idx < 0)
        {
          idx = tlmListOld();
          if (idx > -1)
            memset(&Telemetry[idx], 0, sizeof(Telemetry_struct));
        }
        if (idx > -1)
        {
          Telemetry[idx].time = now();
          strcpy(Telemetry[idx].callsign, (char *)src_call.c_str());

          for (int i = 0; i < 3; i++)
            Telemetry[idx].UNIT[i][5] = 0;
          if (aprs.flags & F_UNIT)
          {
            memcpy(Telemetry[idx].UNIT, aprs.tlm_unit.val, sizeof(Telemetry[idx].UNIT));
          }
          else if (aprs.flags & F_PARM)
          {
            memcpy(Telemetry[idx].PARM, aprs.tlm_parm.val, sizeof(Telemetry[idx].PARM));
          }
          else if (aprs.flags & F_EQNS)
          {
            Telemetry[idx].EQNS_FLAG = true;
            for (int i = 0; i < 15; i++)
              Telemetry[idx].EQNS[i] = aprs.tlm_eqns.val[i];
          }
          else if (aprs.flags & F_BITS)
          {
            Telemetry[idx].BITS_FLAG = aprs.telemetry.bitsFlag;
          }
          else if (aprs.flags & F_TLM)
          {
            for (int i = 0; i < 5; i++)
              Telemetry[idx].RAW[i] = aprs.telemetry.val[i];
            Telemetry[idx].BITS = aprs.telemetry.bits;
            show = true;
          }

          for (int i = 0; i < 4; i++)
          { // Cut length
            if (strstr(Telemetry[idx].PARM[i], "RxTraffic") != 0)
              sprintf(Telemetry[idx].PARM[i], "RX");
            if (strstr(Telemetry[idx].PARM[i], "TxTraffic") != 0)
              sprintf(Telemetry[idx].PARM[i], "TX");
            if (strstr(Telemetry[idx].PARM[i], "RxDrop") != 0)
              sprintf(Telemetry[idx].PARM[i], "DROP");
            Telemetry[idx].PARM[i][6] = 0;
            Telemetry[idx].UNIT[i][3] = 0;
            for (int a = 0; a < 3; a++)
            {
              if (Telemetry[idx].UNIT[i][a] == '/')
                Telemetry[idx].UNIT[i][a] = 0;
            }
          }

          for (int i = 0; i < 5; i++)
          {
            if (Telemetry[idx].PARM[i][0] == 0)
            {
              sprintf(Telemetry[idx].PARM[i], "CH%d", i + 1);
            }
          }
        }
        if (show || filter == false)
        {
          display.drawRoundRect(0, 16, 128, 48, 5, WHITE);
          display.fillRoundRect(1, 17, 126, 10, 2, WHITE);
          display.setTextColor(BLACK);
          display.setCursor(40, 18);
          display.print("TELEMETRY");
          display.setFont();
          display.setTextColor(WHITE);
          display.setCursor(2, 28);
          display.print(Telemetry[idx].PARM[0]);
          display.print(":");

          if (Telemetry[idx].EQNS_FLAG == true)
          {
            for (int i = 0; i < 5; i++)
            {
              // a*v^2+b*v+c
              Telemetry[idx].VAL[i] = (Telemetry[idx].EQNS[(i * 3) + 0] * pow(Telemetry[idx].RAW[i], 2));
              Telemetry[idx].VAL[i] += Telemetry[idx].EQNS[(i * 3) + 1] * Telemetry[idx].RAW[i];
              Telemetry[idx].VAL[i] += Telemetry[idx].EQNS[(i * 3) + 2];
            }
          }
          else
          {
            for (int i = 0; i < 5; i++)
            {
              // a*v^2+b*v+c
              Telemetry[idx].VAL[i] = Telemetry[idx].RAW[i];
            }
          }

          if (fmod(Telemetry[idx].VAL[0], 1) == 0)
            display.print(Telemetry[idx].VAL[0], 0);
          else
            display.print(Telemetry[idx].VAL[0], 1);
          display.print(Telemetry[idx].UNIT[0]);
          display.setCursor(65, 28);
          display.print(Telemetry[idx].PARM[1]);
          display.print(":");
          if (fmod(Telemetry[idx].VAL[1], 1) == 0)
            display.print(Telemetry[idx].VAL[1], 0);
          else
            display.print(Telemetry[idx].VAL[1], 1);
          display.print(Telemetry[idx].UNIT[1]);
          display.setCursor(2, 37);
          display.print(Telemetry[idx].PARM[2]);
          display.print(":");
          if (fmod(Telemetry[idx].VAL[2], 1) == 0)
            display.print(Telemetry[idx].VAL[2], 0);
          else
            display.print(Telemetry[idx].VAL[2], 1);
          display.print(Telemetry[idx].UNIT[2]);
          display.setCursor(65, 37);
          display.print(Telemetry[idx].PARM[3]);
          display.print(":");
          if (fmod(Telemetry[idx].VAL[3], 1) == 0)
            display.print(Telemetry[idx].VAL[3], 0);
          else
            display.print(Telemetry[idx].VAL[3], 1);
          display.print(Telemetry[idx].UNIT[3]);
          display.setCursor(2, 46);
          display.print(Telemetry[idx].PARM[4]);
          display.print(":");
          display.print(Telemetry[idx].VAL[4], 1);
          display.print(Telemetry[idx].UNIT[4]);

          display.setCursor(4, 55);
          display.print("BIT");
          uint8_t bit = Telemetry[idx].BITS;
          for (int i = 0; i < 8; i++)
          {
            if (bit & 0x80)
            {
              display.fillCircle(30 + (i * 12), 58, 3, WHITE);
            }
            else
            {
              display.drawCircle(30 + (i * 12), 58, 3, WHITE);
            }
            bit <<= 1;
          }
          // display.print(Telemetry[idx].BITS, BIN);

          // display.setFont();
          // display.setCursor(2, 30);
          // memset(&text[0], 0, sizeof(text));
          // memcpy(&text[0], aprs.comment, aprs.comment_len);
          // display.setTextColor(WHITE);
          // display.print(aprs.comment);
          display.display();
        }
        return;
      }
      else if (aprs.packettype & T_STATUS)
      {
        display.drawRoundRect(0, 16, 128, 48, 5, WHITE);
        display.fillRoundRect(1, 17, 126, 10, 2, WHITE);
        display.setTextColor(BLACK);
        display.setCursor(48, 18);
        display.print("STATUS");

        display.setFont();
        display.setCursor(2, 30);
        // memset(&text[0], 0, sizeof(text));
        // memcpy(&text[0], aprs.comment, aprs.comment_len);
        display.setTextColor(WHITE);
        display.print(aprs.comment);
        display.display();
        return;
      }
      else if (aprs.packettype & T_QUERY)
      {
        display.drawRoundRect(0, 16, 128, 48, 5, WHITE);
        display.fillRoundRect(1, 17, 126, 10, 2, WHITE);
        display.setTextColor(BLACK);
        display.setCursor(48, 18);
        display.print("?QUERY?");
        // memset(&text[0], 0, sizeof(text));
        // memcpy(&text[0], aprs.comment, aprs.comment_len);
        display.setFont();
        display.setTextColor(WHITE);
        display.setCursor(2, 30);
        display.print(aprs.comment);
        display.display();
        return;
      }
      else if (aprs.packettype & T_MESSAGE)
      {
        if (aprs.msg.is_ack == 1)
        {
        }
        else if (aprs.msg.is_rej == 1)
        {
        }
        else
        {
          display.drawRoundRect(0, 16, 128, 48, 5, WHITE);
          display.fillRoundRect(1, 17, 126, 10, 2, WHITE);
          display.setTextColor(BLACK);
          display.setCursor(48, 18);
          display.print("MESSAGE");
          display.setCursor(108, 18);
          display.print("{");
          strncpy(&text[0], aprs.msg.msgid, aprs.msg.msgid_len);
          int msgid = atoi(text);
          display.print(msgid, DEC);
          display.print("}");
          // memset(&text[0], 0, sizeof(text));
          // memcpy(&text[0], aprs.comment, aprs.comment_len);
          display.setFont();
          display.setTextColor(WHITE);
          display.setCursor(2, 30);
          display.print("To: ");
          strncpy(&text[0], aprs.dstname, aprs.dstname_len);
          display.print(text);
          String mycall;
          if (config.aprs_ssid == 0)
            mycall = config.aprs_mycall;
          else
            mycall = config.aprs_mycall + String("-") + String(config.aprs_ssid, DEC);
          if (strcmp(mycall.c_str(), text) == 0)
          {
            display.setCursor(2, 54);
            display.print("ACK:");
            display.println(msgid);
            sendIsAckMsg(src_call, msgid);
            //  client.println(raw);
            //  SerialTNC.println("}" + raw);
            //  if (slot == 0) {
            //	client.println(raw);
            // }
            //  else {
            //	SerialTNC.println("}" + raw);
            // }
          }
          strncpy(&text[0], aprs.msg.body, aprs.msg.body_len);
          display.setCursor(2, 40);
          display.print("Msg: ");
          display.println(text);

          display.display();
        }
        return;
      }
      display.setFont();
      display.drawFastHLine(0, 16, 128, WHITE);
      display.drawFastVLine(48, 16, 48, WHITE);
      x = 8;

      if (aprs.srcname_len > 0)
      {
        x += 9;
        display.fillRoundRect(51, 16, 77, 9, 2, WHITE);
        display.setTextColor(BLACK);
        display.setCursor(53, x);
        display.print("By " + src_call);
        display.setTextColor(WHITE);
        // x += 9;
      }
      if (aprs.packettype & T_WX)
      {
        // Serial.println("WX Display");
        if (aprs.wx_report.flags & W_TEMP)
        {
          display.setCursor(58, x += 10);
          display.drawYBitmap(51, x, &Temperature_Symbol[0], 5, 8, WHITE);
          display.printf("%.1fC", aprs.wx_report.temp);
        }
        if (aprs.wx_report.flags & W_HUM)
        {
          display.setCursor(102, x);
          display.drawYBitmap(95, x, &Humidity_Symbol[0], 5, 8, WHITE);
          display.printf("%d%%", aprs.wx_report.humidity);
        }
        if (aprs.wx_report.flags & W_BAR)
        {
          display.setCursor(58, x += 9);
          display.drawYBitmap(51, x, &Pressure_Symbol[0], 5, 8, WHITE);
          display.printf("%.1fhPa", aprs.wx_report.pressure);
        }
        if (aprs.wx_report.flags & W_R24H)
        {
          // if (aprs.wx_report.rain_1h > 0) {
          display.setCursor(58, x += 9);
          display.drawYBitmap(51, x, &Rain_Symbol[0], 5, 8, WHITE);
          display.printf("%.1fmm.", aprs.wx_report.rain_24h);
          //}
        }
        if (aprs.wx_report.flags & W_PAR)
        {
          // if (aprs.wx_report.luminosity > 10) {
          display.setCursor(51, x += 9);
          display.printf("%c", 0x0f);
          display.setCursor(58, x);
          display.printf("%dW/m", aprs.wx_report.luminosity);
          if (aprs.wx_report.flags & W_UV)
          {
            display.printf(" UV%d", aprs.wx_report.uv);
          }
          //}
        }
        if (aprs.wx_report.flags & W_WS)
        {
          display.setCursor(58, x += 9);
          display.drawYBitmap(51, x, &Wind_Symbol[0], 5, 8, WHITE);
          // int dirIdx=map(aprs.wx_report.wind_dir, -180, 180, 0, 8); ((angle+22)/45)%8]
          int dirIdx = ((aprs.wx_report.wind_dir + 22) / 45) % 8;
          if (dirIdx > 8)
            dirIdx = 8;
          display.printf("%.1fkPh(%s)", aprs.wx_report.wind_speed, directions[dirIdx]);
        }
        // Serial.printf("%.1fkPh(%d)", aprs.wx_report.wind_speed, aprs.wx_report.wind_dir);
        if (aprs.flags & F_HASPOS)
        {

          double dtmp = aprsParse.direction(lon, lat, aprs.lng, aprs.lat);
          double dist = aprsParse.distance(lon, lat, aprs.lng, aprs.lat);
          // if (config.h_up == true) {
          // 	//double course = gps.course.deg();
          // 	double course = SB_HEADING;
          // 	if (dtmp >= course) {
          // 		dtmp -= course;
          // 	}
          // 	else {
          // 		double diff = dtmp - course;
          // 		dtmp = diff + 360.0F;
          // 	}
          // 	compass_label(25, 37, 15, course, WHITE);
          // 	display.setCursor(0, 17);
          // 	display.printf("H");
          // }
          // else {
          compass_label(25, 37, 15, 0.0F, WHITE);
          //}
          // compass_label(25, 37, 15, 0.0F, WHITE);
          compass_arrow(25, 37, 12, dtmp, WHITE);
          display.drawFastHLine(1, 63, 45, WHITE);
          display.drawFastVLine(1, 58, 5, WHITE);
          display.drawFastVLine(46, 58, 5, WHITE);
          display.setCursor(4, 55);
          if (dist > 999)
            display.printf("%.fKm", dist);
          else
            display.printf("%.1fKm", dist);
        }
        else
        {
          display.setCursor(20, 30);
          display.printf("NO\nPOSITION");
        }
      }
      else if (aprs.flags & F_HASPOS)
      {
        // display.setCursor(50, x += 10);
        // display.printf("LAT %.5f\n", aprs.lat);
        // display.setCursor(51, x+=9);
        // display.printf("LNG %.4f\n", aprs.lng);
        String str;
        int l = 0;
        display.setCursor(50, x += 10);
        display.print("LAT:");
        str = String(aprs.lat, 5);
        l = str.length() * 6;
        display.setCursor(128 - l, x);
        display.print(str);

        display.setCursor(50, x += 9);
        display.print("LON:");
        str = String(aprs.lng, 5);
        l = str.length() * 6;
        display.setCursor(128 - l, x);
        display.print(str);

        double dtmp = aprsParse.direction(lon, lat, aprs.lng, aprs.lat);
        double dist = aprsParse.distance(lon, lat, aprs.lng, aprs.lat);
        // if (config.h_up == true) {
        // 	//double course = gps.course.deg();
        // 	double course = SB_HEADING;
        // 	if (dtmp>=course) {
        // 		dtmp -= course;
        // 	}
        // 	else {
        // 		double diff = dtmp-course;
        // 		dtmp = diff+360.0F;
        // 	}
        // 	compass_label(25, 37, 15, course, WHITE);
        // 	display.setCursor(0, 17);
        // 	display.printf("H");
        // }
        // else {
        compass_label(25, 37, 15, 0.0F, WHITE);
        //}
        compass_arrow(25, 37, 12, dtmp, WHITE);
        display.drawFastHLine(1, 55, 45, WHITE);
        display.drawFastVLine(1, 55, 5, WHITE);
        display.drawFastVLine(46, 55, 5, WHITE);
        display.setCursor(4, 57);
        if (dist > 999)
          display.printf("%.fKm", dist);
        else
          display.printf("%.1fKm", dist);

        if (aprs.flags & F_CSRSPD)
        {
          display.setCursor(51, x += 9);
          // display.printf("SPD %d/", aprs.course);
          // display.setCursor(50, x += 9);
          display.printf("SPD %.1fkPh\n", aprs.speed);
          int dirIdx = ((aprs.course + 22) / 45) % 8;
          if (dirIdx > 8)
            dirIdx = 8;
          display.setCursor(51, x += 9);
          display.printf("CSD %d(%s)", aprs.course, directions[dirIdx]);
        }
        if (aprs.flags & F_ALT)
        {
          display.setCursor(51, x += 9);
          display.printf("ALT %.1fM\n", aprs.altitude);
        }
        if (aprs.flags & F_PHG)
        {
          int power, height, gain;
          // unsigned char tmp;
          power = (int)aprs.phg[0] - 0x30;
          power *= power;
          height = (int)aprs.phg[1] - 0x30;
          height = 10 << (height + 1);
          height = height / 3.2808;
          gain = (int)aprs.phg[2] - 0x30;
          display.setCursor(51, x += 9);
          display.printf("PHG %dM.\n", height);
          display.setCursor(51, x += 9);
          display.printf("PWR %dWatt\n", power);
          display.setCursor(51, x += 9);
          display.printf("ANT %ddBi\n", gain);
        }
        if (aprs.flags & F_RNG)
        {
          display.setCursor(51, x += 9);
          display.printf("RNG %dKm\n", aprs.radio_range);
        }
        /*if (aprs.comment_len > 0) {
            display.setCursor(0, 56);
            display.print(aprs.comment);
        }*/
      }
      display.display();
    }
  }
}

void userDisp()
{
  display.setTextColor(WHITE);
  display.drawRect(2, 2, 122, 60, WHITE); // draws frame with rounded edges
  display.setCursor(18, 20);
  display.setTextSize(1);
  display.setFont(&FreeSansBold9pt7b);
  display.print("APRS AIO");
  int CallSignLenght = String(config.aprs_mycall).length();
  if (CallSignLenght < 4)
    CallSignLenght = 4;
  else if (CallSignLenght > 6)
    CallSignLenght = 6;
  display.setCursor(30 - ((CallSignLenght - 4) * 6), 48);
  display.print(config.aprs_mycall);
  display.print("-");
  display.print(config.aprs_ssid);
  display.setFont();
  display.display();
}

void blankDisp()
{
  display.setTextColor(WHITE);
  display.drawRect(2, 2, 122, 60, WHITE); // draws frame with rounded edges
  display.setCursor(5, 32);
  display.setTextSize(1);
  display.setFont(&FreeSansBold9pt7b);
  display.print("SCREEN OFF");
  display.display();
}

void statisticsDisp()
{
  display.setFont();
  display.clearDisplay();

  // uint8 wifi = 0, i;
  int x;
  String str;
  // display.fillRect(0, 16, 128, 10, WHITE);
  // display.drawLine(0, 16, 0, 63, WHITE);
  // display.drawLine(127, 16, 127, 63, WHITE);
  // display.drawLine(0, 63, 127, 63, WHITE);
  // display.fillRect(1, 25, 126, 38, BLACK);
  // display.setTextColor(BLACK);
  // display.setCursor(30, 17);
  // display.print("STATISTICS");
  // display.setCursor(108, 17);
  // display.print("1/5");
  // display.setTextColor(WHITE);

  display.fillRect(0, 0, 128, 15, WHITE);
  display.drawRect(0, 16, 128, 48, WHITE);
  display.fillRect(1, 17, 126, 46, BLACK);

  display.setCursor(5, 7);
  display.setTextSize(1);
  display.setFont(&FreeSansBold9pt7b);
  display.setTextColor(BLACK);
  display.print("STATISTIC");
  display.setFont();
  display.setCursor(108, 7);
  display.print("1/4");
  display.setTextColor(WHITE);

  display.setCursor(3, 18);
  display.print("ALL DATA");
  str = String(status.allCount, DEC);
  x = str.length() * 6;
  display.setCursor(126 - x, 18);
  display.print(str);

  display.setCursor(3, 26);
  display.print("DIGI RPT");
  str = String(status.digi, DEC);
  x = str.length() * 6;
  display.setCursor(126 - x, 26);
  display.print(str);

  display.setCursor(3, 35);
  display.print("RF->INET");
  str = String(status.rf2inet, DEC);
  x = str.length() * 6;
  display.setCursor(126 - x, 35);
  display.print(str);

  display.setCursor(3, 44);
  display.print("INET->RF");
  str = String(status.inet2rf, DEC);
  x = str.length() * 6;
  display.setCursor(126 - x, 44);
  display.print(str);

  display.setCursor(3, 53);
  display.print("ERROR/DROP");
  str = String(status.errorCount + status.dropCount, DEC);
  x = str.length() * 6;
  display.setCursor(126 - x, 53);
  display.print(str);

  display.display();
}

void pkgLastDisp()
{

  uint8_t k = 0;
  int i;
  // char list[4];
  // int x;
  int y;
  String str;
  // String times;
  // pkgListType *ptr[100];

  display.fillRect(0, 0, 128, 15, WHITE);
  display.drawRect(0, 16, 128, 48, WHITE);
  display.fillRect(1, 17, 126, 46, BLACK);

  display.setCursor(15, 7);
  display.setTextSize(1);
  display.setFont(&FreeSansBold9pt7b);
  display.setTextColor(BLACK);
  display.print("STATION");
  display.setFont();
  display.setCursor(108, 7);
  display.print("2/4");
  display.setTextColor(WHITE);

  // display.fillRect(0, 16, 128, 10, WHITE);
  // display.drawLine(0, 16, 0, 63, WHITE);
  // display.drawLine(127, 16, 127, 63, WHITE);
  // display.drawLine(0, 63, 127, 63, WHITE);
  // display.fillRect(1, 25, 126, 38, BLACK);
  // display.setTextColor(BLACK);
  // display.setCursor(27, 17);
  // display.print("LAST STATIONS");
  // display.setCursor(108, 17);
  // display.print("2/5");
  // display.setTextColor(WHITE);

  sort(pkgList, PKGLISTSIZE);
  k = 0;
  for (i = 0; i < PKGLISTSIZE; i++)
  {
    if (pkgList[i].time > 0)
    {
      y = 18 + (k * 9);
      // display.drawBitmap(3, y, &SYMBOL[0][0], 11, 6, WHITE);
      display.fillRoundRect(2, y, 7, 8, 2, WHITE);
      display.setCursor(3, y);
      pkgList[i].calsign[10] = 0;
      display.setTextColor(BLACK);
      switch (pkgList[i].type)
      {
      case PKG_OBJECT:
        display.print("O");
        break;
      case PKG_ITEM:
        display.print("I");
        break;
      case PKG_MESSAGE:
        display.print("M");
        break;
      case PKG_WX:
        display.print("W");
        break;
      case PKG_TELEMETRY:
        display.print("T");
        break;
      case PKG_QUERY:
        display.print("Q");
        break;
      case PKG_STATUS:
        display.print("S");
        break;
      default:
        display.print("*");
        break;
      }
      display.setTextColor(WHITE);
      display.setCursor(10, y);
      display.print(pkgList[i].calsign);
      display.setCursor(126 - 48, y);
      // display.printf("%02d:%02d:%02d", hour(pkgList[i].time), minute(pkgList[i].time), second(pkgList[i].time));

      // time_t tm = pkgList[i].time;
      struct tm tmstruct;
      localtime_r(&pkgList[i].time, &tmstruct);
      String str = String(tmstruct.tm_hour, DEC) + ":" + String(tmstruct.tm_min, DEC) + ":" + String(tmstruct.tm_sec, DEC);
      display.print(str);
      // str = String(hour(pkgList[i].time),DEC) + ":" + String(minute(pkgList[i].time), DEC) + ":" + String(second(pkgList[i].time), DEC);
      ////str = String(pkgList[pkgLast_array[i]].time, DEC);
      // x = str.length() * 6;
      // display.setCursor(126 - x, y);
      // display.print(str);
      k++;
      if (k >= 5)
        break;
    }
  }
  display.display();
}

void pkgCountDisp()
{

  // uint8 wifi = 0, k = 0, l;
  uint k = 0;
  int i;
  // char list[4];
  int x, y;
  String str;
  // String times;
  // pkgListType *ptr[100];

  display.fillRect(0, 0, 128, 15, WHITE);
  display.drawRect(0, 16, 128, 48, WHITE);
  display.fillRect(1, 17, 126, 46, BLACK);

  display.setCursor(20, 7);
  display.setTextSize(1);
  display.setFont(&FreeSansBold9pt7b);
  display.setTextColor(BLACK);
  display.print("TOP PKG");
  display.setFont();
  display.setCursor(108, 7);
  display.print("3/4");
  display.setTextColor(WHITE);

  // display.setCursor(3, 18);

  // display.fillRect(0, 16, 128, 10, WHITE);
  // display.drawLine(0, 16, 0, 63, WHITE);
  // display.drawLine(127, 16, 127, 63, WHITE);
  // display.drawLine(0, 63, 127, 63, WHITE);
  // display.fillRect(1, 25, 126, 38, BLACK);
  // display.setTextColor(BLACK);
  // display.setCursor(30, 17);
  // display.print("TOP PACKAGE");
  // display.setCursor(108, 17);
  // display.print("3/5");
  // display.setTextColor(WHITE);

  sortPkgDesc(pkgList, PKGLISTSIZE);
  k = 0;
  for (i = 0; i < PKGLISTSIZE; i++)
  {
    if (pkgList[i].time > 0)
    {
      y = 18 + (k * 9);
      // display.drawBitmapV(2, y-1, &SYMBOL[pkgList[i].symbol][0], 11, 8, WHITE);
      pkgList[i].calsign[10] = 0;
      display.fillRoundRect(2, y, 7, 8, 2, WHITE);
      display.setCursor(3, y);
      pkgList[i].calsign[10] = 0;
      display.setTextColor(BLACK);
      switch (pkgList[i].type)
      {
      case PKG_OBJECT:
        display.print("O");
        break;
      case PKG_ITEM:
        display.print("I");
        break;
      case PKG_MESSAGE:
        display.print("M");
        break;
      case PKG_WX:
        display.print("W");
        break;
      case PKG_TELEMETRY:
        display.print("T");
        break;
      case PKG_QUERY:
        display.print("Q");
        break;
      case PKG_STATUS:
        display.print("S");
        break;
      default:
        display.print("*");
        break;
      }
      display.setTextColor(WHITE);
      display.setCursor(10, y);
      display.print(pkgList[i].calsign);
      str = String(pkgList[i].pkg, DEC);
      x = str.length() * 6;
      display.setCursor(126 - x, y);
      display.print(str);
      k++;
      if (k >= 5)
        break;
    }
  }
  display.display();
}

void systemDisp()
{

  // uint8 wifi = 0, k = 0, l;
  // char i;
  // char list[4];
  int x;
  String str;
  time_t upTime = now() - systemUptime;
  // String times;
  // pkgListType *ptr[100];

  // display.fillRect(0, 16, 128, 10, WHITE);
  // display.drawLine(0, 16, 0, 63, WHITE);
  display.fillRect(0, 0, 128, 15, WHITE);
  // display.drawLine(0, 16, 0, 63, WHITE);

  // display.drawLine(127, 16, 127, 63, WHITE);
  // display.drawLine(0, 63, 127, 63, WHITE);
  // display.fillRect(1, 25, 126, 38, BLACK);
  display.drawRect(0, 16, 128, 48, WHITE);
  display.fillRect(1, 17, 126, 46, BLACK);
  // display.fillRoundRect(1, 17, 126, 46, 2, WHITE);

  display.setCursor(20, 7);
  display.setTextSize(1);
  display.setFont(&FreeSansBold9pt7b);
  display.setTextColor(BLACK);
  display.print("SYSTEM");
  display.setFont();
  display.setCursor(108, 7);
  display.print("4/4");
  display.setTextColor(WHITE);

  display.setCursor(3, 18);
  // display.print("HMEM:");
  display.print("MAC");
  // str = String(ESP.getFreeHeap(), DEC)+"Byte";
  str = String(WiFi.macAddress());
  x = str.length() * 6;
  display.setCursor(126 - x, 18);
  display.print(str);

  display.setCursor(3, 26);
  display.print("IP:");
  str = String(WiFi.localIP().toString());
  x = str.length() * 6;
  display.setCursor(126 - x, 26);
  display.print(str);

  display.setCursor(3, 35);
  display.print("UPTIME:");
  str = String(day(upTime) - 1, DEC) + "D " + String(hour(upTime), DEC) + ":" + String(minute(upTime), DEC) + ":" + String(second(upTime), DEC);
  x = str.length() * 6;
  display.setCursor(126 - x, 35);
  display.print(str);

  display.setCursor(3, 44);
  display.print("WiFi RSSI:");
  str = String(WiFi.RSSI()) + "dBm";
  // str = String(str_status[WiFi.status()]);
  x = str.length() * 6;
  display.setCursor(126 - x, 44);
  display.print(str);

  display.setCursor(3, 53);
  display.print("Firmware:");
  str = "V" + String(VERSION);
  x = str.length() * 6;
  display.setCursor(126 - x, 53);
  display.print(str);

  display.display();
}
