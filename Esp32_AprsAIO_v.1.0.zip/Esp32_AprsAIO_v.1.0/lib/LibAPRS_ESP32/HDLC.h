#ifndef PROTOCOL_HDLC_H
#define PROTOCOL_HDLC_H

#define HDLC_FLAG  0x7E
#define HDLC_RESET 0x7F
#define AX25_ESC   0x1B

#endif